#!/bin/bash
chmod +x ./*.sh

# ./twisted.sh

# ./cubane.sh
# ./cubane-cross.sh
./cubane-n.sh
./cubane-cross-n.sh

./caffeine-from-smiles.sh
./caffeine-from-smiles-rotated.sh

./daptomycin1.sh
./daptomycin-u.sh

./printoptions.sh

./phenol-from-smiles.sh
./phenol-from-smiles-w.sh
./phenol-from-smiles-wz.sh
./phenol-as-submol.sh
./phenol-add-h.sh

./doxo-from-sdf.sh
./doxo-strip-h.sh
./doxo-numbered.sh
./doxo-recalculated.sh
./doxo-recalculated-flopped.sh
./doxo-recalculated-rotated.sh

./dichlorofluorescein1.sh
./dichlorofluorescein2.sh
./dichlorofluorescein3.sh

./morphine.sh
./morphine-f.sh
./morphine-n.sh
./morphine-k.sh

./plp.sh

./mp.sh