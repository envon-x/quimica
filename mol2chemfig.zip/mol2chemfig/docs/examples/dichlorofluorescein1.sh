mol2chemfig -l dcf1 dichlorofluorescein.mol > dcf-submol1.tex
mol2chemfig -l ce1 crown-ether.mol > ce-submol1.tex
