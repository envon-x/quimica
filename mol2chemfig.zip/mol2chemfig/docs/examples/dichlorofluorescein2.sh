# numbered versions
mol2chemfig -n -l dcf2 dichlorofluorescein.mol > dcf-submol2.tex
mol2chemfig -n -l ce2 crown-ether.mol > ce-submol2.tex
