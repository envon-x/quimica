# correctly ordered versions
mol2chemfig -e 22 -l dcf3 dichlorofluorescein.mol > dcf-submol3.tex
mol2chemfig -e 12 -x 32 -l ce3 crown-ether.mol > ce-submol3.tex
