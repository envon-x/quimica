mol2chemfig -f -w morphine.mol > morphine-f.tex
