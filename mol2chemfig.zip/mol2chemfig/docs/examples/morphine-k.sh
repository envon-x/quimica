mol2chemfig -k 19-20 -wf morphine.mol > morphine-k.tex
