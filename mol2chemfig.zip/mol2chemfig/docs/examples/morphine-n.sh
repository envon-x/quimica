mol2chemfig -n -w morphine.mol > morphine-n.tex
