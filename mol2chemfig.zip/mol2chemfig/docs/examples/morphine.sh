mol2chemfig -w morphine.mol > morphine.tex
