mol2chemfig -f -l mp -g mp -a 270 mp.mol > mp.tex
