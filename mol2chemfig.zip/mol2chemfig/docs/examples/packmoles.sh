zip example-mol.zip *.mol *.smi *.sdf
