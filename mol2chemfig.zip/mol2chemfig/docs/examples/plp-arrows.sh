mol2chemfig -f -l plp  plp.mol  > plp.tex
mol2chemfig -f -l plp2 plp2.mol > plp2.tex