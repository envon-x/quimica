mol2chemfig -t 2 -wn twisted.mol > twisted-n.tex
mol2chemfig -t 2 -w  twisted.mol > twisted-simple.tex
mol2chemfig -t 2 -w -k 2-4 twisted.mol > twisted-k.tex
