from distutils.core import setup

setup(name='mol2chemfig',
      version='1.5',
      description='Full version of mol2chemfig',
      #summary='Full version of mol2chemfig',
      license='The LaTeX project public license',
      package_dir={'mol2chemfig':'src'},
      author='Michael Palmer',
      author_email='mpalmer@uwaterloo.ca',
      url='http://chimpsky.uwaterloo.ca/mol2chemfig/',
      scripts=['mol2chemfig','mol2chemfig.cmd'],
      packages=["mol2chemfig"]
)
